
/**
*  FakeLMS utility
*  Used this page as reference : http://scorm.com/scorm-explained/technical-scorm/run-time/run-time-reference/
*  
*/

// adapted from https://raw.githubusercontent.com/sadstag/fakelms/master/lib/fakelms.js

// there are TWO classes:   FakeLMSAPI and FakeLMS






// SCORM 1.2  API Signature
//
// LMSInitialize( “” ) : bool – Begins a communication session with the LMS.
// LMSFinish( “” ) : bool – Ends a communication session with the LMS.
// LMSGetValue( element : CMIElement ) : string – Retrieves a value from the LMS.
// LMSSetValue( element : CMIElement, value : string) : string – Saves a value to the LMS.
// LMSCommit( “” ) : bool – Indicates to the LMS that all data should be persisted (not required).
// LMSGetLastError() : CMIErrorCode – Returns the error code that resulted from the last API call.
// LMSGetErrorString( errorCode : CMIErrorCode ) : string – Returns a short string describing the specified error code.
// LMSGetDiagnostic( errorCode : CMIErrorCode ) : string – Returns detailed information about the last error that occurred.


// SCORM 2004 2nd Edition API Signature
// SCORM 2004 4th Edition   API Signature
//
// Initialize( “” ) : bool – Begins a communication session with the LMS.
// Terminate( “” ) : bool – Ends a communication session with the LMS.
// GetValue( element : CMIElement ) : string – Retrieves a value from the LMS.
// SetValue( element : CMIElement, value : string) : string – Saves a value to the LMS.
// Commit( “” ) : bool – Indicates to the LMS that all data should be persisted (not required).
// GetLastError() : CMIErrorCode – Returns the error code that resulted from the last API call.
// GetErrorString( errorCode : CMIErrorCode ) : string – Returns a short string describing the specified error code.
// GetDiagnostic( errorCode : CMIErrorCode ) : string – Returns detailed information about the last error that occurred.





let debug = true;


// SCORM 1.2 Error Codes
//
// No error (0) No error occurred, the previous API call was successful.
// General Exception (101) No specific error code exists to describe the error. Use LMSGetDiagnostic for more information.
// Invalid argument error (201) Indicates that an argument represents an invalid data model element or is otherwise incorrect.
// Element cannot have children (202) Indicates that LMSGetValue was called with a data model element name that ends in “_children” for a data model element that does not support the “_children” suffix.
// Element not an array. Cannot have count. (203) Indicates that LMSGetValue was called with a data model element name that ends in “_count” for a data model element that does not support the “_count” suffix.
// Not initialized (301) Indicates that an API call was made before the call to LMSInitialize.
// Not implemented error (401) The data model element indicated in a call to LMSGetValue or LMSSetValue is valid, but was not implemented by this LMS. SCORM 1.2 defines a set of data model elements as being optional for an LMS to implement.
// Invalid set value, element is a keyword (402) Indicates that LMSSetValue was called on a data model element that represents a keyword (elements that end in “_children” and “_count”).
// Element is read only. (403) LMSSetValue was called with a data model element that can only be read.
// Element is write only (404) LMSGetValue was called on a data model element that can only be written to.
// Incorrect Data Type (405) LMSSetValue was called with a value that is not consistent with the data format of the supplied data model element.


let errString = new Map()

let ERR_NoError = 0; errString.set(0, "NoError")
let ERR_GeneralException = 101; errString.set(101, "GeneralException")
let ERR_InvalidArgument = 201; errString.set(201, "InvalidArgument")
let ERR_ElementCannotHaveChildren = 202; errString.set(202, "ElementCannotHaveChildren")
let ERR_ElementIsNotAnArray = 203; errString.set(203, "ElementIsNotAnArray")
let ERR_NotInitialized = 301; errString.set(301, "NotInitialized")
let ERR_NotImplemented = 401; errString.set(401, "NotImplemented")
let ERR_InvalidSetValue = 402; errString.set(402, "InvalidSetValue")
let ERR_ElementIsReadOnly = 403; errString.set(403, "ElementIsReadOnly")
let ERR_ElementIsWriteOnly = 404; errString.set(404, "ElementIsWriteOnly")
let ERR_IncorrectDataType = 405; errString.set(405, "IncorrectDataType")


// SCORM 2004 4th Edition   API Signature
//
// Error Codes
// No Error (0) No error occurred, the previous API call was successful.
// General Exception (101) No specific error code exists to describe the error. Use GetDiagnostic for more information.
// General Initialization Failure (102) Call to Initialize failed for an unknown reason.
// Already Initialized (103) Call to Initialize failed because Initialize was already called.
// Content Instance Terminated (104) Call to Initialize failed because Terminate was already called.
// General Termination Failure (111) Call to Terminate failed for an unknown reason.
// Termination Before Initialization (112) Call to Terminate failed because it was made before the call to Initialize.
// Termination After Termination (113) Call to Terminate failed because Terminate was already called.
// Retrieve Data Before Initialization (122) Call to GetValue failed because it was made before the call to Initialize.
// Retrieve Data After Termination (123) Call to GetValue failed because it was made after the call to Terminate.
// Store Data Before Initialization (132) Call to SetValue failed because it was made before the call to Initialize.
// Store Data After Termination (133) Call to SetValue failed because it was made after the call to Terminate.
// Commit Before Initialization (142) Call to Commit failed because it was made before the call to Initialize.
// Commit After Termination (143) Call to Commit failed because it was made after the call to Terminate.
// General Argument Error (201) An invalid argument was passed to an API method (usually indicates that Initialize, Commit or Terminate did not receive the expected empty string argument.
// General Get Failure (301) Indicates a failed GetValue call where no other specific error code is applicable. Use GetDiagnostic for more information.
// General Set Failure (351) Indicates a failed SetValue call where no other specific error code is applicable. Use GetDiagnostic for more information.
// General Commit Failure (391) Indicates a failed Commit call where no other specific error code is applicable. Use GetDiagnostic for more information.
// Undefined Data Model Element (401) The data model element name passed to GetValue or SetValue is not a valid SCORM data model element.
// Unimplemented Data Model Element (402) The data model element indicated in a call to GetValue or SetValue is valid, but was not implemented by this LMS. In SCORM 2004, this error would indicate an LMS that is not fully SCORM conformant.
// Data Model Element Value Not Initialized (403) Attempt to read a data model element that has not been initialized by the LMS or through a SetValue call. This error condition is often reached during normal execution of a SCO.
// Data Model Element Is Read Only (404) SetValue was called with a data model element that can only be read.
// Data Model Element Is Write Only (405) GetValue was called on a data model element that can only be written to.
// Data Model Element Type Mismatch (406) SetValue was called with a value that is not consistent with the data format of the supplied data model element.
// Data Model Element Value Out Of Range (407) The numeric value supplied to a SetValue call is outside of the numeric range allowed for the supplied data model element.
// Data Model Dependency Not Established (408) Some data model elements cannot be set until another data model element was set. This error condition indicates that the prerequisite element was not set before the dependent element.




class FakeLMSAPI {

    status: 'Started' | 'Initialized' | 'Terminated'
    lastErrcode: number
    lastErrString: string
    sessionTime: number

    LMS: FakeLMS

    constructor() {
        this.LMS = new FakeLMS()

        this.status = 'Started'   // but not initialized 
        this.sessionTime = Date.now()
        this.lastErrcode = ERR_NoError
        this.lastErrString = ''
    }

    ///////////////////////////////////
    // this section are basic utilities
    ///////////////////////////////////

    _result(errcode: number, errString?: string) {
        this.lastErrcode = errcode;
        this.lastErrString = errString ?? ''
    }

    _fail(errcode: number, errmsg = '') {
        let message = 'ERROR' + errmsg + ' ' + errString.get(errcode)
        console.error(`FAIL ${errcode} - ${message}`)
        this._result(errcode);
        return false;
    }

    _ok() {
        this._result(0 /* NO_ERROR */);
        return true;
    }



    ///////////////////////////////////////////////////////////////////
    // this section are minimal interfaces for SCORM 1.2 and SCORM 2004
    ///////////////////////////////////////////////////////////////////



    LMSInitialize(x: string): boolean {   // SCORM 1.2
        return this.Initialize(x)
    }

    Initialize(x: string): boolean {  // SCORM 2004 2nd Edition  
        if ("string" != typeof x || x.length !== 0) {
            console.error(`Expected empty string, got '${x}'`)
            return this._fail(ERR_InvalidArgument, 'Expected empty string');
        }

        console.assert(this.LMS.isAvailable())
        this.status = 'Initialized'

        // if (this.status !== FakeLMS.STATUS.STARTED) {
        //     console.log(`Initialize FAILURE`)
        //     return this._fail(ERR_GeneralException, 'already initialized' /*General Exception*/);
        // }

        // this.sessionTime = 0;
        // if (null == window.localStorage.getItem('total_time')) {
        //     window.localStorage.setItem('lesson_location', '')
        //     window.localStorage.setItem('lesson_status', 'incomplete')
        //     window.localStorage.setItem('total_time', '0.0');
        // }
        // this.status = FakeLMS.STATUS.INITIALIZED;
        return this._ok()
    }


    LMSFinish(x: string): boolean {   // SCORM 1.2
        return this.Terminate(x)
    }
    Terminate(x: any): boolean {   // SCORM 2004 2nd Edition
        if ("string" != typeof x || x.length !== 0) {
            console.error(`Expected empty string, got '${x}'`)
            return this._fail(ERR_InvalidArgument, 'Expected empty string');
        }
        if (this.status !== 'Initialized') {
            return this._fail(ERR_NotInitialized, 'Terminate - Not Initialized');
        }
        this.status = 'Terminated'
        return true

        // switch (this.status) {
        //     case FakeLMS.STATUS.STARTED:
        //         return this._fail(ERR_GeneralException, 'termination before initialization');
        //     case FakeLMS.STATUS.INITIALIZED:
        //         break; // normal case
        //     case FakeLMS.STATUS.TERMINATED:
        //         // no specific error is designed for this
        //         // maybe not so important, lat just warn
        //         console.warn('LMS API : Terminate() called after termination');
        //         break;
        //     default:
        //         return this._fail(ERR_GeneralException, 'Unknown status ' + this.status);
        // }
        // this.status = FakeLMS.STATUS.TERMINATED;
        // // updating total_time by adding last set sessionTime
        // let totalTimeString = window.localStorage.getItem('total_time')
        // if (totalTimeString == null)
        //     totalTimeString = this.sessionTime.toString()
        // else
        //     totalTimeString = (parseInt(totalTimeString) + this.sessionTime).toString()

        // window.localStorage.setItem('total_time', totalTimeString);
        return this._ok();
    }


    LMSGetValue(path: string): string {   // SCORM 1.2
        return this.GetValue(path)
    }
    GetValue(path: any): string {    // SCORM 2004 2nd Edition
        if (this.status !== 'Initialized') {
            this._fail(ERR_NotInitialized)
        }
        let [value, error] = this.LMS.getValue(path)
        if (error !== ERR_NoError)
            this._fail(error)
        else {
            this._ok()
        }
        return value
    }


    //     if ('string' != typeof path) {
    //         return this._fail(ERR_InvalidArgument, 'GetValue takes a string as parameter');
    //     }
    //     var parts = path.split('.');
    //     if (parts.length < 2) {
    //         return this._fail(ERR_InvalidArgument, 'undefined data element ' + path);
    //     }
    //     if ('cmi' != parts) {
    //         return this._fail(ERR_NotImplemented, `'${path} is not implemented`);
    //     }
    //     if (-1 != ["exit", "sessionTime"].indexOf(parts[1])) {
    //         return this._fail(ERR_ElementIsWriteOnly);
    //     }


    //     if (parts[1] !== 'core') {
    //         // we only support the 'core' data elements 
    //         return this._fail(ERR_NotImplemented, `Not implemented (not core) ` + path);
    //     }

    //     switch (parts[2]) {   // skip cmi.core....

    //         // these are string RW fields
    //         case 'lesson_status':
    //         case 'lesson_location':
    //             console.log(`'${path}' is ${window.localStorage.getItem(parts[2])}`)
    //             return window.localStorage.getItem(parts[2]);
    //             break;


    //         case 'total_time':
    //             return "PT" + window.localStorage.getItem('total_time') + "S";
    //             break;
    //         case 'interactions':
    //             if (parts.length < 3) {
    //                 return this._fail(ERR_InvalidArgument, 'Unknown data element : ' + path);
    //             }
    //             let interactionsString = window.localStorage.getItem('interactions');
    //             let interactions: any // but hopefully 'object' or 'array

    //             if (null == interactionsString) {     // if not already set, then set to empty array
    //                 window.localStorage.setItem('interactions', JSON.stringify([]));  // empty array
    //             } else {
    //                 try {
    //                     interactions = JSON.parse(interactionsString);
    //                 } catch (e) {
    //                     return this._fail(ERR_GeneralException, "internal : interactions parse error :" + e.message);
    //                 }
    //             }
    //             if ('object' != typeof interactions) {
    //                 return this._fail(ERR_IncorrectDataType, "internal : interactions is not an object");
    //             }
    //             if (!Array.isArray(interactions)) {
    //                 return this._fail(ERR_IncorrectDataType, "internal : interactions is not an array");
    //             }
    //     }

    //     // this is a hot mess ...
    //     // let nbInteractions: number = interaction.length;
    //     // switch (parts[2]) {
    //     //     case '_count':
    //     //         return nbInteractions;
    //     //     case '_children':
    //     //         return FakeLMS.SUPPORTED_INTERACTIONS_FIELDS;
    //     //     default:
    //     //         // must be an integer
    //     //         if (!parts[2].match(/^[0-9]+$/)) {
    //     //             return this._fail(ERR_InvalidArgument, 'Unknown data element : ' + path);
    //     //         }
    //     //         var n = parseInt(parts[2], 10);
    //     //         if (n >= nbInteractions) {
    //     //             return this._fail(ERR_NotInitialized  /*not initialized*/);
    //     //         }
    //     //         let interaction = nbInteractions[n];
    //     //         if (parts.length < 4) {
    //     //             return this._fail(ERR_InvalidArgument, 'Unknown data element : ' + path);
    //     //         }
    //     //         var field = parts[3];
    //     //         if (-1 == FakeLMS.SUPPORTED_INTERACTIONS_FIELDS.indexOf(field)) {
    //     //             return this._fail(ERR_NotImplemented, `Not implemented ` + path);
    //     //         }
    //     //         if (!(field in interaction)) {
    //     //             return this._fail(ERR_NotInitialized , 'not initialized : ' + path);
    //     //         }
    //     //         return interaction[field];
    //     //         break;
    //     // }
    //     return this._fail(ERR_NotImplemented, 'not initialized : ' + path);
    // }



    LMSSetValue(path: string, value: string | number) {   // SCORM 1.2
        return this.SetValue(path, value)
    }

    SetValue(path: string, value: string | number) {    // SCORM 2004 2nd Edition
        console.log(`set value ${value} path ${path}`)

        if (this.status !== 'Initialized') {
            this._fail(ERR_NotInitialized)
        }

        let error = this.LMS.setValue(path, value)
        if (error == ERR_NoError) {
            this._ok()
            return true
        }
        else {
            this._fail(error)
            return false
        }
    }

    //     //current_location seems to be a number in SCORM demo
    //     let stringValue = value.toString()        // force to string


    //     // if ('string' != typeof path || 'string' != typeof value) {
    //     //     return this._fail(ERR_InvalidArgument, 'SetValue takes strings as parameters');
    //     // }
    //     var parts = path.split('.');
    //     if (parts.length < 2) {
    //         return this._fail(ERR_InvalidArgument, JSON.stringify(parts));
    //     }
    //     if ('cmi' != parts) {
    //         return this._fail(ERR_InvalidArgument, `expected 'cmi' ` + JSON.stringify(parts));
    //     }
    //     if (-1 != ["total_time"].indexOf(parts[1])) {
    //         return this._fail(ERR_InvalidArgument, `did not find total time in ` + JSON.stringify(parts));
    //     }
    //     switch (parts[1]) {
    //         case 'exit':
    //             if (-1 == ["timeout", "suspend", "logout", "normal", ""].indexOf(stringValue)) {
    //                 return this._fail(ERR_InvalidArgument, 'out of range');
    //             }
    //             window.localStorage.setItem('exit', stringValue); // not really necessary ? (cms.exit is write-only)
    //             break;
    //         case 'completion_status':
    //             if (-1 == ["completed", "incomplete", "not attempted", "unknown"].indexOf(stringValue)) {
    //                 return this._fail(ERR_InvalidArgument, 'out of range');
    //             }
    //             window.localStorage.setItem('completion_status', stringValue);
    //             break;
    //         case 'success_status':
    //             if (-1 == ["passed", "failed", "unknown"].indexOf(stringValue)) {
    //                 return this._fail(ERR_InvalidArgument, 'out of range');
    //             }
    //             window.localStorage.setItem('success_status', stringValue);
    //             break;
    //         case 'sessionTime':
    //             var captured = /PT(\d+)S/.exec(stringValue);
    //             if (null == captured) {
    //                 return this._fail(ERR_InvalidArgument, "set cmi.sessionTime with value that do not match /PT\\d+S/ (sole pattern recognized so far)");
    //             }
    //             this.sessionTime = parseInt(captured[1]);
    //             break;
    //         case 'interactions':
    //             if (parts.length < 3) {
    //                 return this._fail(ERR_InvalidArgument, 'Unknown data element : ' + path);
    //             }

    //             let interactionsString = window.localStorage.getItem('interactions');
    //             let interactions: any // but hopefully 'object' or 'array

    //             if (null == interactionsString) {     // if not already set, then set to empty array
    //                 window.localStorage.setItem('interactions', JSON.stringify([]));  // empty array
    //             } else {
    //                 try {
    //                     interactions = JSON.parse(interactions);
    //                 } catch (e) {
    //                     return this._fail(ERR_GeneralException, "internal : interactions parse error : " + e.message);
    //                 }
    //             }
    //             if ('object' != typeof interactions) {
    //                 return this._fail(ERR_GeneralException, "internal : interactions is not an object");
    //             }
    //             if (!Array.isArray(interactions)) {
    //                 return this._fail(ERR_GeneralException, "internal : interactions is not an array");
    //             }
    //             var nbInteractions = interactions.length;
    //             switch (parts[2]) {
    //                 case '_count':
    //                 case '_children':
    //                     return this._fail(ERR_ElementIsReadOnly /*read only*/);
    //                 default:
    //                     if (parts.length < 4) {
    //                         return this._fail(ERR_InvalidArgument, 'unknown data element' + JSON.stringify(parts));
    //                     }
    //                     // must be an integer
    //                     if (!parts[2].match(/^[0-9]+$/)) {
    //                         return this._fail(ERR_InvalidArgument, 'unknown data element' + JSON.stringify(parts));
    //                     }
    //                 // var field = parts[3];
    //                 // if (-1 == FakeLMS.SUPPORTED_INTERACTIONS_FIELDS.indexOf(field)) {
    //                 //     return this._fail(ERR_NotImplemented, 'not initialized : ' + path);
    //                 // }
    //                 // if ('type' == field) {
    //                 //     if (-1 == FakeLMS.VALID_INTERACTIONS_TYPE_VALUES.indexOf(stringValue)) {
    //                 //         return this._fail(ERR_InvalidArgument, `out of range` + JSON.stringify(parts));
    //                 //     }
    //                 // }
    //                 // var n = parseInt(parts[2], 10);
    //                 // if (n >= nbInteractions) {
    //                 //     // initializing missing elements with 'blank' interactions
    //                 //     for (var i = nbInteractions; i <= n; i++) {
    //                 //         interactions.push({
    //                 //             id: i,
    //                 //             type: 'true-false',
    //                 //             learner_response: 'true'
    //                 //         });
    //                 //     }
    //                 // }
    //                 // interactions[n][field] = value;
    //                 // window.localStorage.setItem('interactions', JSON.stringify(interactions));
    //                 // break; // normal case
    //             }
    //             break;
    //         default:
    //             return this._fail(ERR_NotInitialized);
    //     }
    //     return this._ok();
    // }



    LMSCommit(x: string) {   // SCORM 1.2
        return this.Commit(x)
    }

    /**  Does nothing ! Should be called on real LMS though.   */
    Commit(x: any) {    // SCORM 2004 2nd Edition
        if ("string" != typeof x || x.length) {
            return this._fail(ERR_InvalidArgument, 'Commit expected empty string');
        }
        if (this.status !== 'Initialized') {
            return this._fail(ERR_NotInitialized, 'Commit - Not Initialized');
        }

        return this._ok();
    }



    LMSGetLastError() {   // SCORM 1.2
        return this.GetLastError()
    }

    GetLastError() {  // SCORM 2004 2nd Edition
        return this.lastErrcode;
    }


    LMSGetErrorString(x: number) {   // SCORM 1.2
        return this.GetErrorString(x)
    }
    GetErrorString(errcode: number) {  // SCORM 2004 2nd Edition
        return this.lastErrString
    }


    LMSGetDiagnostic(x: number) {   // SCORM 1.2
        return this.GetDiagnostic(x)
    }
    GetDiagnostic(errCode: number) {    // SCORM 2004 2nd Edition
        if (this.status !== 'Initialized') {
            return this._fail(ERR_NotInitialized, 'GetDiagnostic - Not Initialized');
        }
        return this.lastErrString;
    }

}














type dataElement = {
    path: string,
    access: 'RO' | 'RW' | 'WO',
    validate: <T = string>(value: T) => number,    // number is an error code
    get: Function,
    set: Function
}




export class FakeLMS {

    dataModel: dataElement[] = []

    student_name = 'Tom'
    student_id = '123456'
    lesson_location = ''        // empty means not yet set
    lesson_status = '"not attempted"'

    constructor() {
        this.setUpDataModel()
    }


    dataModelFactory(
        path: string,
        access: 'RO' | 'RW' | 'WO',
        validate: <T = string>(value: T) => number,    // number is an error code
        get: Function,
        set: Function
    ) {
        this.dataModel.push({ path: path, access: access, validate: validate, get: get, set: set })
    }



    /**
    * Return the value for the given key.
    *  For now only cmi.interactions.* paths are supported.
    *  @param {string} path the identifier of the requested value
    */




    /** Tells whether FakeLMS is usable here and now   */
    isAvailable() {
        if (typeof localStorage !== 'undefined' && 'localStorage' in window) {
            // test localStorage
            localStorage.setItem('testStorage', 'abc')
            return (localStorage.getItem('testStorage') === 'abc')
        }
        return false
    }




    //** LMS is queried for a value, returns [string,error#] */
    getValue(path: string): [string, number] {
        let dm = this.dataModel.find((element) => element.path == path)
        // console.log('Valid for get', this.dataModel, path, dm)

        if (dm === undefined) {       // can't find that path (cmi.something_weird)
            return ['', ERR_NotImplemented]
        } else {
            if (dm.access == 'WO') {        // can't read that path
                return ['', ERR_ElementIsWriteOnly]
            }
            return [dm.get(path), ERR_NoError]
        }
    }



    //** LMS receives a value, returns a number with error */
    setValue(path: string, value: string | number): number {
        let dm = this.dataModel.find((element) => element.path == path)
        // console.log('Valid for set', this.dataModel, path, dm)

        if (dm === undefined) {       // can't find that path (cmi.something_weird)
            return ERR_NotImplemented
        } else {
            if (dm.access == 'RO') {        // can't read that path
                return ERR_ElementIsReadOnly
            }
            let valid = dm.validate(value)
            if (valid !== ERR_NoError) {
                return valid
            }
            dm.set(value)
            return (ERR_NoError)
        }
    }




    /** Attaches the fake LMS API to the window object so that you can discover it like a genuine one.    */
    static attachLMSAPIToWindow() {   // NB - STATIC !!!
        (window as any).API = new FakeLMSAPI();
        (window as any).API2 = new FakeLMSAPI();
        (window as any).API_1484_11 = new FakeLMSAPI();
    }

    clearData() {
        ['exit', 'success_status', 'completion_status', 'interactions'].forEach(window.localStorage.removeItem.bind(window.localStorage));
        window.localStorage.setItem('total_time', '');
    }



    ////////////////////////////// set up data model




    // Data Model SCORM 1.2

    // cmi.core._children (student_id, student_name, lesson_location, credit, lesson_status, entry, score, total_time, lesson_mode, exit, session_time, RO) Listing of supported data model elements
    // cmi.core.student_id (CMIString (SPM: 255), RO) Identifies the student on behalf of whom the SCO was launched
    // cmi.core.student_name (CMIString (SPM: 255), RO) Name provided for the student by the LMS
    // cmi.core.lesson_location (CMIString (SPM: 255), RW) The learner’s current location in the SCO
    // cmi.core.credit (“credit”, “no-credit”, RO) Indicates whether the learner will be credited for performance in the SCO
    // cmi.core.lesson_status (“passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”, RW) Indicates whether the learner has completed and satisfied the requirements for the SCO
    // cmi.core.entry (“ab-initio”, “resume”, “”, RO) Asserts whether the learner has previously accessed the SCO
    // cmi.core.score_children (raw,min,max, RO) Listing of supported data model elements
    // cmi.core.score.raw (CMIDecimal, RW) Number that reflects the performance of the learner relative to the range bounded by the values of min and max
    // cmi.core.score.max (CMIDecimal, RW) Maximum value in the range for the raw score
    // cmi.core.score.min (CMIDecimal, RW) Minimum value in the range for the raw score
    // cmi.core.total_time (CMITimespan, RO) Sum of all of the learner’s session times accumulated in the current learner attempt
    // cmi.core.lesson_mode (“browse”, “normal”, “review”, RO) Identifies one of three possible modes in which the SCO may be presented to the learner
    // cmi.core.exit (“time-out”, “suspend”, “logout”, “”, WO) Indicates how or why the learner left the SCO
    // cmi.core.session_time (CMITimespan, WO) Amount of time that the learner has spent in the current learner session for this SCO

    // cmi.suspend_data (CMIString (SPM: 4096), RW) Provides space to store and retrieve data between learner sessions
    // cmi.launch_data (CMIString (SPM: 4096), RO) Data provided to a SCO after launch, initialized from the dataFromLMS manifest element
    // cmi.comments (CMIString (SPM: 4096), RW) Textual input from the learner about the SCO
    // cmi.comments_from_lms (CMIString (SPM: 4096), RO) Comments or annotations associated with a SCO
    // cmi.objectives._children (id,score,status, RO) Listing of supported data model elements
    // cmi.objectives._count (non-negative integer, RO) Current number of objectives being stored by the LMS
    // cmi.objectives.n.id (CMIIdentifier, RW) Unique label for the objective
    // cmi.objectives.n.score._children (raw,min,max, RO) Listing of supported data model elements
    // cmi.objectives.n.score.raw (CMIDecimal, RW) Number that reflects the performance of the learner, for the objective, relative to the range bounded by the values of min and max
    // cmi.objectives.n.score.max (CMIDecimal, Rw) Maximum value, for the objective, in the range for the raw score
    // cmi.objectives.n.score.min (CMIDecimal, RW) Minimum value, for the objective, in the range for the raw score
    // cmi.objectives.n.status (“passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”, RW) Indicates whether the learner has completed or satisfied the objective
    // cmi.student_data._children (mastery_score, max_time_allowed, time_limit_action, RO) Listing of supported data model elements
    // cmi.student_data.mastery_score (CMIDecimal, RO) Passing score required to master the SCO
    // cmi.student_data.max_time_allowed (CMITimespan, RO) Amount of accumulated time the learner is allowed to use a SCO
    // cmi.student_data.time_limit_action (exit,message,” “exit,no message”,” continue,message”, “continue, no message”, RO) Indicates what the SCO should do when max_time_allowed is exceeded
    // cmi.student_preference._children (audio,language,speed,text, RO) Listing of supported data model elements
    // cmi.student_preference.audio (CMISInteger, RW) Specifies an intended change in perceived audio level
    // cmi.student_preference.language (CMIString (SPM: 255), RW) The student’s preferred language for SCOs with multilingual capability
    // cmi.student_preference.speed (CMISInteger, RW) The learner’s preferred relative speed of content delivery
    // cmi.student_preference.text (CMISInteger, RW) Specifies whether captioning text corresponding to audio is displayed
    // cmi.interactions._children (id,objectives,time,type,correct_responses,weighting,student_response,result,latency, RO) Listing of supported data model elements
    // cmi.interactions._count (CMIInteger, RO) Current number of interactions being stored by the LMS
    // cmi.interactions.n.id (CMIIdentifier, WO) Unique label for the interaction
    // cmi.interactions.n.objectives._count (CMIInteger, RO) Current number of objectives (i.e., objective identifiers) being stored by the LMS for this interaction
    // cmi.interactions.n.objectives.n.id (CMIIdentifier, WO) Label for objectives associated with the interaction
    // cmi.interactions.n.time (CMITime, WO) Point in time at which the interaction was first made available to the student for student interaction and response
    // cmi.interactions.n.type (“true-false”, “choice”, “fill-in”, “matching”, “performance”, “sequencing”, “likert”, “numeric”, WO) Which type of interaction is recorded
    // cmi.interactions.n.correct_responses._count (CMIInteger, RO) Current number of correct responses being stored by the LMS for this interaction
    // cmi.interactions.n.correct_responses.n.pattern (format depends on interaction type, WO) One correct response pattern for the interaction
    // cmi.interactions.n.weighting (CMIDecimal, WO) Weight given to the interaction relative to other interactions
    // cmi.interactions.n.student_response (format depends on interaction type, WO) Data generated when a student responds to an interaction
    // cmi.interactions.n.result (“correct”, “wrong”, “unanticipated”, “neutral”, “x.x [CMIDecimal]”, WO) Judgment of the correctness of the learner response
    // cmi.interactions.n.latency (CMITimespan, WO) Time elapsed between the time the interaction was made available to the learner for response and the time of the first response





    setUpDataModel(): dataElement[] {


        // in case we get called twice 
        let dataModel: dataElement[] = []     // array of {name, access, validate, get, set}  from dataModelFactory



        this.dataModelFactory(  // cmi.core._children (student_id, student_name, lesson_location, credit, lesson_status, entry, score, total_time, lesson_mode, exit, session_time, RO) Listing of supported data model elements
            'cmi.core._children',
            'RO',
            (value: any) => (typeof value == 'string') ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.student_id (CMIString (SPM: 255) RO) Identifies the student on behalf of whom the SCO was launched
            'cmi.core.student_id',
            'RO',
            (value: any) => (typeof value == 'string') ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => this.student_id,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.student_name (CMIString (SPM: 255) RO) Name provided for the student by the LMS
            'cmi.core.student_name',
            'RO',
            (value: any) => (typeof value == 'string') ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => this.student_name,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.lesson_location (CMIString (SPM: 255) RW) The learner’s current location in the SCO
            'cmi.core.lesson_location',
            'RW',
            (value: any) => (typeof value == 'string') ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => this.lesson_location,
            (value: any) => this.lesson_location = value,
        )

        this.dataModelFactory( // cmi.core.credit (“credit”, “no-credit”, RO) Indicates whether the learner will be credited for performance in the SCO
            'cmi.core.credit',
            'RO',
            (value: any) => ["credit", "no-credit"].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.lesson_status (“passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”, RW) Indicates whether the learner has completed and satisfied the requirements for the SCO
            'cmi.core.lesson_status',
            'RW',
            (value: any) => ["passed", "completed", "failed", "incomplete", "browsed", "not attempted"].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => this.lesson_status,
            (value: any) => this.lesson_status = value,
        )

        this.dataModelFactory( // cmi.core.entry (“ab-initio”, “resume”, “”, RO) Asserts whether the learner has previously accessed the SCO
            'cmi.core.entry',
            'RO',
            (value: any) => ["ab-initio", "resume", ""].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.score_children (raw,min,max, RO) Listing of supported data model elements
            'cmi.core.score_children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.score.raw (CMIDecimal, RW) Number that reflects the performance of the learner relative to the range bounded by the values of min and max
            'cmi.core.score.raw',
            'RW',
            (value: any) => typeof value == 'number' ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.score.max (CMIDecimal, RW) Maximum value in the range for the raw score
            'cmi.core.score.max',
            'RW',
            (value: any) => typeof value == 'number' ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.score.min (CMIDecimal, RW) Minimum value in the range for the raw score
            'cmi.core.score.min',
            'RW',
            (value: any) => typeof value == 'number' ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.total_time (CMITimespan, RO) Sum of all of the learner’s session times accumulated in the current learner attempt
            'cmi.core.total_time',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.lesson_mode (“browse”, “normal”, “review”, RO) Identifies one of three possible modes in which the SCO may be presented to the learner
            'cmi.core.lesson_mode',
            'RO',
            (value: any) => ["browse", "normal", "review"].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.exit (“time-out”, “suspend”, “logout”, “”, WO) Indicates how or why the learner left the SCO
            'cmi.core.exit',
            'WO',
            (value: any) => ["time-out", "suspend", "logout", ""].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.core.session_time (CMITimespan, WO) Amount of time that the learner has spent in the current learner session for this SCO
            'cmi.core.session_time',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.suspend_data (CMIString (SPM: 4096) RW) Provides space to store and retrieve data between learner sessions
            'cmi.suspend_data',
            'RW',
            (value: any) => typeof value == 'string' && value.length < 4096 ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.launch_data (CMIString (SPM: 4096) RO) Data provided to a SCO after launch, initialized from the dataFromLMS manifest element
            'cmi.launch_data',
            'RO',
            (value: any) => typeof value == 'string' && value.length < 4096 ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.comments (CMIString (SPM: 4096) RW) Textual input from the learner about the SCO
            'cmi.comments',
            'RW',
            (value: any) => typeof value == 'string' && value.length < 4096 ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.comments_from_lms (CMIString (SPM: 4096) RO) Comments or annotations associated with a SCO
            'cmi.comments_from_lms',
            'RO',
            (value: any) => typeof value == 'string' && value.length < 4096 ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives._children (id,score,status, RO) Listing of supported data model elements
            'cmi.objectives._children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives._count (non-negative integer, RO) Current number of objectives being stored by the LMS
            'cmi.objectives._count',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.id (CMIIdentifier, RW) Unique label for the objective
            'cmi.objectives.n.id',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.score._children (raw,min,max, RO) Listing of supported data model elements
            'cmi.objectives.n.score._children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.score.raw (CMIDecimal, RW) Number that reflects the performance of the learner, for the objective, relative to the range bounded by the values of min and max
            'cmi.objectives.n.score.raw',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.score.max (CMIDecimal, Rw) Maximum value, for the objective, in the range for the raw score
            'cmi.objectives.n.score.max',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.score.min (CMIDecimal, RW) Minimum value, for the objective, in the range for the raw score
            'cmi.objectives.n.score.min',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.objectives.n.status (“passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”, RW) Indicates whether the learner has completed or satisfied the objective
            'cmi.objectives.n.status',
            'RO',
            (value: any) => ["passed", "completed", "failed", "incomplete", "browsed", "not attempted"].includes(value) ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_data._children (mastery_score, max_time_allowed, time_limit_action, RO) Listing of supported data model elements
            'cmi.student_data._children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_data.mastery_score (CMIDecimal, RO) Passing score required to master the SCO
            'cmi.student_data.mastery_score',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_data.max_time_allowed (CMITimespan, RO) Amount of accumulated time the learner is allowed to use a SCO
            'cmi.student_data.max_time_allowed',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_data.time_limit_action (exit,message,” “exit,no message”,” continue,message”, “continue, no message”, RO) Indicates what the SCO should do when max_time_allowed is exceeded
            'cmi.student_data.time_limit_action',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_preference._children (audio,language,speed,text, RO) Listing of supported data model elements
            'cmi.student_preference._children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_preference.audio (CMISInteger, RW) Specifies an intended change in perceived audio level
            'cmi.student_preference.audio',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_preference.language (CMIString (SPM: 255) RW) The student’s preferred language for SCOs with multilingual capability
            'cmi.student_preference.language',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_preference.speed (CMISInteger, RW) The learner’s preferred relative speed of content delivery
            'cmi.student_preference.speed',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.student_preference.text (CMISInteger, RW) Specifies whether captioning text corresponding to audio is displayed
            'cmi.student_preference.text',
            'RW',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions._children (id,objectives,time,type,correct_responses,weighting,student_response,result,latency, RO) Listing of supported data model elements
            'cmi.interactions._children',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions._count (CMIInteger, RO) Current number of interactions being stored by the LMS
            'cmi.interactions._count',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.id (CMIIdentifier, WO) Unique label for the interaction
            'cmi.interactions.n.id',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.objectives._count (CMIInteger, RO) Current number of objectives (i.e., objective identifiers) being stored by the LMS for this interaction
            'cmi.interactions.n.objectives._count',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.objectives.n.id (CMIIdentifier, WO) Label for objectives associated with the interaction
            'cmi.interactions.n.objectives.n.id',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.time (CMITime, WO) Point in time at which the interaction was first made available to the student for student interaction and response
            'cmi.interactions.n.time',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.type (“true-false”, “choice”, “fill-in”, “matching”, “performance”, “sequencing”, “likert”, “numeric”, WO) Which type of interaction is recorded
            'cmi.interactions.n.type',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.correct_responses._count (CMIInteger, RO) Current number of correct responses being stored by the LMS for this interaction
            'cmi.interactions.n.correct_responses._count',
            'RO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.correct_responses.n.pattern (format depends on interaction type, WO) One correct response pattern for the interaction
            'cmi.interactions.n.correct_responses.n.pattern',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.weighting (CMIDecimal, WO) Weight given to the interaction relative to other interactions
            'cmi.interactions.n.weighting',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.student_response (format depends on interaction type, WO) Data generated when a student responds to an interaction
            'cmi.interactions.n.student_response',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.result (“correct”, “wrong”, “unanticipated”, “neutral”, “x.x [CMIDecimal]”, WO) Judgment of the correctness of the learner response
            'cmi.interactions.n.result',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        this.dataModelFactory( // cmi.interactions.n.latency (CMITimespan, WO) Time elapsed between the time the interaction was made available to the learner for response and the time of the first response
            'cmi.interactions.n.latency',
            'WO',
            (value: any) => true ? ERR_NoError : ERR_InvalidArgument,
            (value: any) => true,
            (value: any) => true,
        )

        return (dataModel)

    }





}
