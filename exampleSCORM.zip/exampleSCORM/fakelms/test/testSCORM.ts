import { Scorm } from '../src/scormAPI'
import { FakeLMS } from '../src/fakelms'


describe('configure SCORMapi', function () {
    it('configure', function () {
        let scorm = new Scorm()
        expect(scorm.version).toBe('');
        expect(scorm.isActive).toBe(false);

        scorm.configure({ version: '1.2', debug: true })
        expect(scorm.version).toBe('1.2');
        expect(scorm.isActive).toBe(false);  // still false until initialized
    });

    it('initialize before FakeLMS', function () {
        let scorm = new Scorm()
        let fakeLMS = new FakeLMS()

        scorm.configure({ version: '1.2', debug: true })
        let success = scorm.initialize()
        expect(success).toBe(false)
    });

    it('initialize after FakeLMS', function () {
        FakeLMS.attachLMSAPIToWindow()
        let scorm = new Scorm()
        scorm.configure({ version: '1.2', debug: true })

        let success = scorm.initialize()
        expect(success).toBe(true)
        expect(scorm.isActive).toBe(true);  
    });

});


///////// try some basic gets and sets

describe('configure SCORMapi', function () {
    it('simple reads and writes', function () {
        FakeLMS.attachLMSAPIToWindow()
        let scorm = new Scorm()
        scorm.configure({ version: '1.2', debug: true })
        scorm.initialize()
        expect(scorm.isActive).toBe(true)

        expect (scorm.get('cmi.core.student_name')).toBe('Tom')
        expect (scorm.get('cmi.core.student_id')).toBe('123456')

        expect (scorm.set('cmi.core.student_id',555)).toBeFalse()   // can't set RO student id
        expect (scorm.get('cmi.core.student_id')).toBe('123456')    // so still should be 123456

        expect (scorm.get('cmi.core.lesson_location')).toBe('')     // not yet set
        expect (scorm.set('cmi.core.lesson_location','first')).toBeTrue()   // set it 
        expect (scorm.get('cmi.core.lesson_location')).toBe('first')   // and pick it up again

        expect (scorm.set('cmi.core.lesson_location',123)).toBeFalse()   // it's a string, not a number
        expect (scorm.get('cmi.core.lesson_location')).toBe('first')   // make sure it wasn't changed

    })

    it('test the status function', function () {
        FakeLMS.attachLMSAPIToWindow()
        let scorm = new Scorm()
        scorm.configure({ version: '1.2', debug: true })
        scorm.initialize()
        expect(scorm.isActive).toBe(true)

        // “passed”, “completed”, “failed”, “incomplete”, “browsed”, “not attempted”, 


        expect (scorm.status()).toBe('incomplete')
        expect (scorm.status('passed')).toBe('passed')

    })

})


