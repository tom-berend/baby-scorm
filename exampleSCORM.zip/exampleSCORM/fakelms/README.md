A minimal LMS for developing SCORM 1.2 packages


The SCORM API is from https://github.com/gamestdio/scorm 

