import SCORMAdapter from './scormAdapter';

window.API = new SCORMAdapter();